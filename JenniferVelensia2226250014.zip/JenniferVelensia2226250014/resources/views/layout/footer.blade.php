    <hr>
    &copy; {{ date('Y') }} Universitas Multi Data Palembang
</body>
</html>