@
@extends('layout.master')
@section('title', 'Halaman Prodi')

@section('content')
<h2>Prodi</h2>
ini halaman prodi
@endsection
