<h2>Dosen</h2>
ini adalah view/dosen/index.blade.php